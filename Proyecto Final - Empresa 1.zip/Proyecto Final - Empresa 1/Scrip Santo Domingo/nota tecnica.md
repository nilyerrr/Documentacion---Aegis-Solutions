
**Nota Técnica:** Las políticas de seguridad (_DHCP Snooping_ y _DAI_) forman parte del diseño teórico oficial, pero se deshabilitaron temporalmente en el laboratorio. Esta medida fue necesaria para evadir un _bug_ conocido de las imágenes virtuales IOL que bloquea los paquetes DHCP, permitiendo así validar la asignación de IPs y la conectividad real.

Comando: 

configure terminal
no ip dhcp snooping
no ip arp inspection vlan 10,20,30,40,50,60,70
end
write memory
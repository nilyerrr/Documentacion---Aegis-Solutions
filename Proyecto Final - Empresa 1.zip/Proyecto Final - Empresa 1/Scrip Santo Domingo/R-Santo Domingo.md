

! ############################################################
! CONFIGURACION R-SD (ROUTER PRINCIPAL - SANTO DOMINGO)
! ############################################################

enable
configure terminal

hostname R-SD
service timestamps debug datetime msec
service timestamps log datetime msec
service password-encryption

! --- 1. Credenciales y Acceso Remoto Seguro (SSH) ---
enable secret cisco123
username admin privilege 15 secret cisco123

no ip domain lookup
ip domain name corporativo.com.do
ip ssh version 2
ip ssh time-out 60
ip ssh authentication-retries 2
crypto key generate rsa modulus 2048

! --- 2. Exclusión de IPs (Reservadas para Gateways HSRP en R14/R15) ---
ip dhcp excluded-address 10.0.16.193 10.0.16.200 ! D. General
ip dhcp excluded-address 10.0.17.49 10.0.17.52   ! RRHH
ip dhcp excluded-address 10.0.16.225 10.0.16.230 ! Cumplimiento
ip dhcp excluded-address 10.0.17.1 10.0.17.5     ! Soporte Tec.
ip dhcp excluded-address 10.0.15.1 10.0.15.10    ! Finanzas
ip dhcp excluded-address 10.0.13.1 10.0.13.10    ! Ventas
ip dhcp excluded-address 10.0.16.1 10.0.16.10    ! Marketing

! --- 3. DHCP Pools (Basado en el VLSM de Santo Domingo) ---
! La IP default-router será la IP virtual (VIP) de HSRP que configurarás en R14 y R15.

ip dhcp pool VLAN10_DirGeneral
 network 10.0.16.192 255.255.255.224
 default-router 10.0.16.193
 dns-server 10.0.10.10
 lease 7

ip dhcp pool VLAN20_RRHH
 network 10.0.17.48 255.255.255.240
 default-router 10.0.17.49
 dns-server 10.0.10.10

ip dhcp pool VLAN30_Cumplimiento
 network 10.0.16.224 255.255.255.224
 default-router 10.0.16.225
 dns-server 10.0.10.10

ip dhcp pool VLAN40_Soporte
 network 10.0.17.0 255.255.255.224
 default-router 10.0.17.1
 dns-server 10.0.10.10

ip dhcp pool VLAN50_Finanzas
 network 10.0.15.0 255.255.255.128
 default-router 10.0.15.1
 dns-server 10.0.10.10

ip dhcp pool VLAN60_Ventas
 network 10.0.13.0 255.255.255.0
 default-router 10.0.13.1
 dns-server 10.0.10.10

ip dhcp pool VLAN70_Marketing
 network 10.0.16.0 255.255.255.128
 default-router 10.0.16.1
 dns-server 10.0.10.10

! --- 4. Configuración de Interfaces ---
! Enlaces P2P hacia los switches multicapa R14 y R15

interface Ethernet0/2
 description Conexion a Multicapa R14
 ip address 10.255.255.1 255.255.255.252
 ip nat inside
 ip ospf 1 area 0
 no shutdown

interface Ethernet0/1
 description Conexion a Multicapa R15
 ip address 10.255.255.5 255.255.255.252
 ip nat inside
 ip ospf 1 area 0
 no shutdown

interface Ethernet0/0
 description Enlace WAN hacia el ISP
 ip address 1.0.0.1 255.255.255.252
 ip nat outside
 no shutdown


! --- 5. Enrutamiento OSPF ---
router ospf 1
 router-id 1.1.1.1
 passive-interface default
 no passive-interface Ethernet0/1
 no passive-interface Ethernet0/2
 no passive-interface Ethernet0/0
 network 10.0.0.0 0.255.255.255 area 0
 default-information originate


! Lista de Acceso para tráfico interesante (VPN vs NAT)
ip access-list extended VPN-TRAFFIC
 remark Trafico que debe ir por la VPN (No NATear)
 permit ip 10.0.0.0 0.255.255.255 10.0.0.0 0.255.255.255

ip access-list extended NAT-INTERNAS
 remark Trafico hacia Internet
 deny ip 10.0.0.0 0.255.255.255 10.0.0.0 0.255.255.255
 permit ip 10.0.0.0 0.255.255.255 any

! --- 7. NAT ---
ip nat inside source list NAT-INTERNAS interface Ethernet0/0 overload

! --- 8. Aseguramiento de Lineas ---
line con 0
 logging synchronous
 login local
 exec-timeout 5 0

line vty 0 4
 login local
 transport input ssh
 exec-timeout 5 0

! --- 9. Banner de Seguridad ---
banner motd #
*************************************************************
ADVERTENCIA: ACCESO RESTRINGIDO.
Toda actividad en este dispositivo esta siendo monitorizada.
CECOMPE - SOC
*************************************************************
#

no ip http server
no ip http secure-server
end
write memory